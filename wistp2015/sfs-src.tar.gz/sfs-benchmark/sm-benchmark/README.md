A program measuring and printing the number of CPU cycles needed for function calls,
with or without switching protection domains
