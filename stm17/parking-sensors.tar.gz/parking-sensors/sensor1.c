
#define SMNAME     sensor1
#define SNONCE     0xcafe

#include "sensor.c"

