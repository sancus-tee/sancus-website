
#define SMNAME     sensor2
#define SNONCE     0xbebe

#include "sensor.c"

