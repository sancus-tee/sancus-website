#ifndef SENSOR_H


#define  SPOT_OCCUPIED  0x01
#define  SPOT_FREE      0x02
#define  CAR_ENTER      0x04
#define  CAR_EXIT       0x08


#endif /* #ifndef SENSOR_H */

