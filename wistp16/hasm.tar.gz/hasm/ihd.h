#ifndef IHD_H
#define IHD_H


void ihd_update_supply_state (uint8_t i);
void ihd_update_active_power_import (uint16_t i);
void ihd_update_active_import_register (uint16_t i);
void ihd_display (void);


#endif /* #ifndef IHD_H */

