#ifndef __APPS_SHELL_DB_H
#define __APPS_SHELL_DB_H

extern struct process db_shell;


#endif

