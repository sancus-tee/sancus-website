#ifndef __APPS_HELLO_WORLD_H
#define __APPS_HELLO_WORLD_H

extern struct process hello_world_process;


#endif

