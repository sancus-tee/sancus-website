#ifndef __APPS_MULTI_THREADING_H
#define __APPS_MULTI_THREADING_H

extern struct process multi_threading_process;


#endif

