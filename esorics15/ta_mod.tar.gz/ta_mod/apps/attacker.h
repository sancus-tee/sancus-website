#ifndef __APPS_ATTACKER_H
#define __APPS_ATTACKER_H

extern struct process attacker_process;


#endif

