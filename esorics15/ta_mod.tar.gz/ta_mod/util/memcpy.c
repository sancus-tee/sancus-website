#define	TAMEMCOPY
#include "bcopy.c"
